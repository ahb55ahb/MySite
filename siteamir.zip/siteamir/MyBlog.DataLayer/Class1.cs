﻿namespace MyBlog.DataLayer
{
    public class Class1
    {

    }
}
