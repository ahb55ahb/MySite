﻿namespace MyBlog.CoreLayer
{
    public class Class1
    {

    }
}
